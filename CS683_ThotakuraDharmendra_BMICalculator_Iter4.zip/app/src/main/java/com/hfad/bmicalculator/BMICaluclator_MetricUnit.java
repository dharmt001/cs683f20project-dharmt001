package com.hfad.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BMICaluclator_MetricUnit extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi_caluclator__metric_unit);
    }
}